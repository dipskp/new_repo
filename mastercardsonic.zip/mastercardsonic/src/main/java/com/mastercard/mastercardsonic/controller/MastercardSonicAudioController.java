package com.mastercard.mastercardsonic.controller;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;

import com.mastercard.mastercardsonic.R;
import com.mastercard.mastercardsonic.listeners.CallbackSonicAudioController;

import java.io.IOException;

/**
 * MastercardSonicAudioController class can be used to control playback
 * of audio files.
 */

public class MastercardSonicAudioController implements MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener, MediaPlayer.OnPreparedListener {

    private enum STATE {
        IDLE,
        PLAY,
        PLAYING,
        STOP,
        CLEAN_UP
    }

    private final String TAG = "MastercardSonicAudioController";

    private CallbackSonicAudioController mCallback;
    private MediaPlayer mPlayer;
    private MediaPlayerThread mThread;
    private STATE currentState = STATE.IDLE;

    MastercardSonicAudioController(CallbackSonicAudioController callback) {
        mCallback = callback;
        initialiseMediaResources();
    }

    /**
     * Created object of media player and sets listener for listening to completion,
     * preparation and errors occurred
     */
    private void initialiseMediaResources() {
        mPlayer = new MediaPlayer();
        mPlayer.setOnCompletionListener(this);
        mPlayer.setOnErrorListener(this);
        mPlayer.setOnPreparedListener(this);
        mPlayer.setLooping(false);
    }

    /**
     * Media player engine will call supplied callback method on media player is prepared
     * @param mediaPlayer - prepared media player
     */
    @Override
    public void onCompletion(MediaPlayer mediaPlayer) {
        if (mCallback != null) {
            mCallback.onCompletion();
        }
        doCleanUp();
    }

    @Override
    public boolean onError(MediaPlayer mediaPlayer, int what, int extra) {
        if (mCallback != null) {

            switch (extra) {
                case MediaPlayer.MEDIA_ERROR_IO:
                    mCallback.onError("File or network related operation errors.");
                    break;
                case MediaPlayer.MEDIA_ERROR_MALFORMED:
                    mCallback.onError("Bitstream is not conforming to the related coding standard or file spec.");
                    break;
                case MediaPlayer.MEDIA_ERROR_UNSUPPORTED:
                    mCallback.onError("Media framework does not support the feature");
                    break;
                case MediaPlayer.MEDIA_ERROR_TIMED_OUT:
                    mCallback.onError("Operation is taking too long to complete");
                    break;
            }
        }
        doCleanUp();
        return false;
    }


    /**
     *  When the preparation completes or when prepareAsync() method call in {@link #prepareSonic(Context)} ()} returns,
     *  the internal player engine then calls a supplied callback method,
     *  onPrepared() of the OnPreparedListener interface.
     *  In return controller will call received callback method onSonicAudioControllerPrepared()
     */

    @Override
    public void onPrepared(MediaPlayer mediaPlayer) {
        mCallback.onSonicAudioControllerPrepared();
    }


    /**
     * Media player stop() and release() method may take a while to process. In order to avoid any glitch
     * new thread will created to perform such tasks and after releasing media player, thread will also be destroyed.
     */
    void playSonic() {
        startPlayerThread();
        currentState = STATE.PLAY;
    }

    /**
     * Calling below method will release media player when no longer required
     */
    void doCleanUp() {
        currentState = STATE.CLEAN_UP;
    }

    /**
     * Sets data source of player and prepares it for playing.
     * Checks if media player has been made null after release.
     * If it is null it will initialize it and will set data source
     *
     * @param context - View context
     */
    void prepareSonic(Context context) {
        if (mPlayer == null) {
            initialiseMediaResources();
        }
        AssetFileDescriptor afd = context.getResources().openRawResourceFd(R.raw.mastercard_sonic);
        if (afd == null) return;
        try {
            mPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            mPlayer.prepareAsync();
        } catch (IOException e) {
            e.printStackTrace();
            mCallback.onError(e.getMessage());
        }
    }

    /**
     * Stops media player and resets media player for future use
     */
    void stopSonic() {
        currentState = STATE.STOP;
    }

    /**
     * Creates new thread for media player play, stop and release operations
     */
    private void startPlayerThread() {
        mThread = new MediaPlayerThread();
        mThread.start();
    }

    private class MediaPlayerThread extends Thread {

        private boolean mStayAlive = true;

        MediaPlayerThread() {
            super("MediaPlayerThread" + TAG);
        }

        @Override
        public void run() {
            while (mStayAlive) {
                if (mPlayer != null) {
                    switch (currentState) {
                        case PLAY:
                            mPlayer.start();
                            currentState = STATE.PLAYING;
                            break;

                        case STOP:
                            if (mPlayer != null) {
                                if (mPlayer.isPlaying()) {
                                    mPlayer.stop();
                                }
                                mPlayer.reset();
                            }
                            mStayAlive = false;
                            break;
                        case CLEAN_UP:
                            if (mPlayer != null) {
                                if (mPlayer.isPlaying()) {
                                    mPlayer.stop();
                                }
                                mPlayer.reset();
                                mPlayer.release();
                                mPlayer = null;
                            }
                            mStayAlive = false;
                            break;

                    }

                    if(!mStayAlive)
                    {
                        // nothing left to do, quit
                        // doing this check after we're done prevents the case where
                        // multiple threads gets spawned
                        mThread = null;
                    }
                }
            }
        }
    }

}
