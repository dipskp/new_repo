package com.mastercard.mastercardsonic.controller;

import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.os.Handler;

import com.mastercard.mastercardsonic.listeners.CallbackMastercardSonic;
import com.mastercard.mastercardsonic.listeners.CallbackSonicAudioController;

/**
 * Class to handle assets of Mastercard Sonic Branding
 */
public class MastercardSonicController implements CallbackSonicAudioController {

    /**
     * SONIC_TUNE_OFFSET : Defines the time lag for animation.
     * Please do not update its value
     */
    private final int SONIC_TUNE_OFFSET = 600; //In milliseconds

    private MastercardSonicAnimationController mSonicAnimationController;
    private MastercardSonicAudioController mSonicAudioController;

    private CallbackMastercardSonic mCallback;

    private Handler mPlayerHandler;
    private boolean isPlaying = false;

    public MastercardSonicController() {
        initialiseMediaResources();
    }

    public void setOnCompletionListener(CallbackMastercardSonic callback) {
        mCallback = callback;
    }

    public AnimationDrawable getSetSonicBackground(Context context) {
        return mSonicAnimationController.getSetSonicBackground(context);
    }

    /**
     * Initialises {@link com.mastercard.mastercardsonic.controller.MastercardSonicAnimationController}
     * & {@link com.mastercard.mastercardsonic.controller.MastercardSonicAudioController}
     */
    private void initialiseMediaResources() {
        mSonicAnimationController = new MastercardSonicAnimationController();
        mSonicAudioController = new MastercardSonicAudioController(this);
        mPlayerHandler = new Handler();
    }

    /**
     * Asks {@link com.mastercard.mastercardsonic.controller.MastercardSonicAudioController} to prepare audio assets
     *
     * @param context - View context
     */
    public void playSonic(Context context) {
        mSonicAudioController.prepareSonic(context);
    }

    @Override
    public void onSonicAudioControllerPrepared() {
        isPlaying = true;
        mSonicAnimationController.startAnimation();
        mPlayerHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                mSonicAudioController.playSonic();
            }
        }, SONIC_TUNE_OFFSET);
    }

    /**
     * Stops animation and does clean-up
     */
    public void stopSonic() {
        isPlaying = false;
        mPlayerHandler.removeCallbacksAndMessages(null);
        mSonicAudioController.stopSonic();
        mSonicAnimationController.stopAnimation();
    }

    /**
     * Returns true if animation is running
     *
     * @return = true/false
     */
    public boolean isPlaying() {
        return isPlaying;
    }

    @Override
    public void onCompletion() {
        isPlaying = false;
        if (mCallback != null) {
            mCallback.onCompletion();
        }
    }

    @Override
    public void onError(String errorMsg) {
        if (mCallback != null) {
            mCallback.onError(errorMsg);
        }
    }

    /**
     * Resets animation drawables, media player and stops listening to handler callbacks
     */
    public void doCleanUp() {

        //double check to prevent any glitches
        stopSonic();

        mSonicAudioController.doCleanUp();
    }
}
