package com.mastercard.mastercardsonic.listeners;

/**
 * Set this interface to {@link com.mastercard.mastercardsonic.widget.MastercardSonicView object}  to
 * listen to the completion of the animation and errors occurred
 */
public interface  CallbackMastercardSonic {

    /**
     * Gets invoked on mastercardsonic view prepared
     */
    void onMasterSonicViewPrepared();

    /**
     * Gets invoked on animation complete
     */
    void onCompletion();

    /**
     * Gets invoked to notify any error occurred during branding animation
     * @param errorMsg - Details of error occurred
     */
    void onError(String errorMsg);


}
