package com.mastercard.mastercardsonic.listeners;

/**
 * Set this interface to {@link com.mastercard.mastercardsonic.controller.MastercardSonicAudioController object}  to
 * listen to the completion of the media plyer and errors occurred
 */
public interface CallbackSonicAudioController {

    /**
     * Gets invoked on medial player is prepared
     */
    void onSonicAudioControllerPrepared();

    /**
     * Gets invoked on animation complete
     */
    void onCompletion();

    /**
     * Gets invoked to notify any error occurred during branding animation
     * @param errorMsg - Details of error occurred
     */
    void onError(String errorMsg);
}
