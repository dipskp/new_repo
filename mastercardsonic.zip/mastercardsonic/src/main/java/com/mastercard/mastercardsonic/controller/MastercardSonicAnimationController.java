package com.mastercard.mastercardsonic.controller;

import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.support.v4.content.ContextCompat;

import com.mastercard.mastercardsonic.R;

/**
 * This class controls the animation drawable applied to the background of the MastercardSonicView
 */
class MastercardSonicAnimationController {

    private AnimationDrawable mAnimationDrawable;

    AnimationDrawable getSetSonicBackground(Context context) {
        mAnimationDrawable = (AnimationDrawable) ContextCompat.getDrawable(context, R.drawable.mastercard_sonic);
        return mAnimationDrawable;
    }

    /**
     * Resets animation by stopping it if it's already running
     */
    void stopAnimation() {
        //Reset animation
        if (mAnimationDrawable != null) {
            mAnimationDrawable.stop();
        }
    }

    /**
     * Starts animation
     */
    void startAnimation() {
        //Reset animation
        stopAnimation();
        if (mAnimationDrawable != null) {
            mAnimationDrawable.start();
        }
    }


}
