package com.mastercard.mastercardsonic.widget;

import android.content.Context;
import android.support.v7.widget.AppCompatImageView;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ViewTreeObserver;

import com.mastercard.mastercardsonic.R;
import com.mastercard.mastercardsonic.controller.MastercardSonicController;
import com.mastercard.mastercardsonic.listeners.CallbackMastercardSonic;

/**
 * Plays the Mastercard Sonic Brand animation. This class adjusts the size of view
 * according to the aspect ratio. For better execution {@linkcom.mastercard.mastercardsonic.listeners.CallbackSonicAudioController}
 * must be implemented to check if the view is been rendered on the screen or not.
 */
public class MastercardSonicView extends AppCompatImageView implements ViewTreeObserver.OnGlobalLayoutListener {

    private final String TAG = "MastercardSonicView";
    /**
     * DEFAULT_WIDTH : Defines default width of the Mastercardsonic drawable
     */
    private final int DEFAULT_WIDTH = 510; //in px

    /**
     * MIN_WIDTH : Defines minimum width of the Mastercardsonic drawable
     */
    private final int MIN_WIDTH = 250; //in px

    /**
     * ASPECT_RATIO_WIDTH_TO_HEIGHT : Defines the aspect ratio of drawable
     */
    private final float ASPECT_RATIO_WIDTH_TO_HEIGHT = 1.3f;

    /**
     * It will communicate with {@link com.mastercard.mastercardsonic.listeners.CallbackMastercardSonic}
     * {@link com.mastercard.mastercardsonic.listeners.CallbackSonicAudioController}
     */
    private MastercardSonicController mMastercardSonicController;

    /**
     * Callback to send view prepared, error and animation complete status
     */
    private CallbackMastercardSonic mCallbackMastercardSonic;
    private boolean isViewPrepared = false;


    public MastercardSonicView(Context context) {
        super(context);
        setUpAssets();
    }

    public MastercardSonicView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setUpAssets();
    }

    public MastercardSonicView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setUpAssets();
    }

    /**
     * Initializes Mastercardsonic animation assets
     */
    private void setUpAssets() {
        mMastercardSonicController = new MastercardSonicController();
        adjustSize();
    }

    /**
     * Resize drawable to avoid distorted rendering of animation.
     * Takes width defined in xml and adjusts height according to the aspect ratio
     */
    private void adjustSize() {
        ViewTreeObserver mViewTreeObserver = getViewTreeObserver();
        mViewTreeObserver.addOnGlobalLayoutListener(this);
    }

    /**
     * This method converts dp unit to equivalent pixels, depending on device density.
     *
     * @param dp      A value in dp (density independent pixels) unit. Which we need to convert into pixels
     * @param context Context to get resources and device specific display metrics
     * @return A float value to represent px equivalent to dp depending on device density
     */
    private float convertDpToPx(Context context, float dp) {
        return dp * context.getResources().getDisplayMetrics().density;
    }

    /**
     * Sets listener to listen to completion of animation and errors
     *
     * @param callbackMastercardSonic - Implemented by the caller, for listening to errors and completion of process
     */
    public void setEventListener(CallbackMastercardSonic callbackMastercardSonic) {
        mCallbackMastercardSonic = callbackMastercardSonic;
        mMastercardSonicController.setOnCompletionListener(callbackMastercardSonic);
    }

    /**
     * Plays mastercardsonic animation and returns error if it's not prepared
     */
    public void playSonic() {
        if (isViewPrepared) {
            mMastercardSonicController.playSonic(getContext());
        } else {
            sendErrorToTheCaller("playSonic()");
        }
    }

    /**
     * Stops mastercardsonic animation and returns error if it's not prepared
     */
    public void stopSonic() {
        if (isViewPrepared) {
            mMastercardSonicController.stopSonic();
        } else {
            sendErrorToTheCaller("stopSonic()");
        }
    }

    /**
     * Returns true if animation is running
     */
    public boolean isRunning() {
        return mMastercardSonicController.isPlaying();
    }

    private void sendErrorToTheCaller(String methodName) {
        String msg = String.format(getContext().getString(R.string.view_prepared_error), methodName);
        if (mCallbackMastercardSonic != null) {
            mCallbackMastercardSonic.onError(msg);
        }
        Log.e(TAG, msg);
    }


    @Override
    protected void onDetachedFromWindow() {
        mMastercardSonicController.doCleanUp();
        super.onDetachedFromWindow();
    }

    @Override
    public void onGlobalLayout() {

        int width = getWidth();
        Log.d("width:", "::" + width);

        if (width == 0) {
            width = DEFAULT_WIDTH;
        } else if (width < MIN_WIDTH) {
            width = MIN_WIDTH;
        }

        getLayoutParams().width = width;
        getLayoutParams().height = (int) (width / ASPECT_RATIO_WIDTH_TO_HEIGHT);
        requestLayout();

        //Remove layout listener when not required
        getViewTreeObserver().removeOnGlobalLayoutListener(this);

        setBackground(mMastercardSonicController.getSetSonicBackground(getContext()));
        isViewPrepared = true;

        //Acknowledge caller that view is prepared to be used
        if (mCallbackMastercardSonic != null) {
            mCallbackMastercardSonic.onMasterSonicViewPrepared();
        }

    }
}
